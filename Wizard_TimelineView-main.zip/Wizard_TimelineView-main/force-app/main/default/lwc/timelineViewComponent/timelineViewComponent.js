import { LightningElement, track, api,wire } from 'lwc';
import getDetails from '@salesforce/apex/TimelineViewController.getDetails'; // Importing Apex Class Named getDetails
import { ShowToastEvent } from 'lightning/platformShowToastEvent'; // Importing ShowToastEvent from lightning/platformShowToastEvent to display toast notifications
import modelHeader from '@salesforce/label/c.Model_Header'; // Importing custom label for model header
import editRecordButton from '@salesforce/label/c.Edit_Record_Button'; // Importing custom label for edit record button
import goToRecordButton from '@salesforce/label/c.GoTo_Record_Button'; // Importing custom label for go to record button
import editRecordModelHeader from '@salesforce/label/c.Edit_Record_Model_Header'; // Importing custom label for edit record model header
import headerWarningMessgae from '@salesforce/label/c.Header_Warning_Messgae'; // Importing custom label for header warning message
import sortingFieldWarningMessgae from '@salesforce/label/c.Sorting_Field_Warning_Message'; // Importing custom label for sorting field warning message
import successMessage from '@salesforce/label/c.Success_Message'; // Importing custom label for success message
import errorMessageOnSubmit from '@salesforce/label/c.Error_Message'; // Importing custom label for error message
import saveButton from '@salesforce/label/c.SaveButton'; // Importing custom label for save button
import warningMessageHeader from '@salesforce/label/c.Warning'; // Importing custom label for warning message
import successHeader from '@salesforce/label/c.SuccessHeader'; // Importing custom label for warning message
import errorHeader from '@salesforce/label/c.ErrorHeader'; // Importing custom label for warning message
import cancelButton from '@salesforce/label/c.CancelButton'; // Importing custom label for cancel button
import { CurrentPageReference } from 'lightning/navigation';

export default class TimelineViewComponent extends LightningElement {

    // Parent object API name
    @api parentObject;
    // Child object API name
    @api childObject;
    // Comma-separated list of fields
    @api fields;
    // Label for the component
    @api label;
    // Icon name
    @api iconName;
    // Background color for the icon
    @api iconBackgroundColor;
    // Standard task color for the icon
    @api iconStandardTaskColor;
    // Color for the timeline strip
    @api stripColor;
    // Record ID of the parent object
    @api recordId;
    // Field used for sorting the timeline items
    @api sortingField;
    // Sorting order for the timeline items (ASC/DESC)
    @api sortingOrder;
    // Header field to display in the timeline
    @api header;

    isLoader = true;
    // Visibility flag for records
    isRecordsVisible;
    // Record ID of the child object
    childObjectRecordId;
    // Flag to check if icon name is present
    isIconNamePresent = false;
    // Flag to check if header exists
    isHeaderExists = false;
    // Flag to check if sorting field exists
    isSortingFieldExists = false;

    // Data fetched from Apex controller
    @track childData;
    // Visibility flag for the timeline
    isTimelineVisible = true;
    // Flag to show/hide edit modal box
    showEditModelBox = false;
    // Component width
    componentWidth = '';
    // Value for the icon
    iconVlaue = '';
    // Background color for the icon
    iconBgColor = '';
    // Array of fields
    fieldsArray = [];
    // Map of field labels
    fieldMap = [];
    // Detailed field map for large screens
    fieldMapDetail = [];
    // Loading flag for the modal
    isLoadingModel = false;
    // Error flag
    isError;
    // Error message
    errorMessage;
    gridClass = '';
    isLoadOnRecord = true;
    isCommunity = false;

    // Custom labels
    label = {
        modelHeader,
        editRecordButton,
        goToRecordButton,
        editRecordModelHeader,
        headerWarningMessgae,
        sortingFieldWarningMessgae,
        errorMessageOnSubmit,
        successMessage,
        saveButton,
        warningMessageHeader,
        successHeader,
        errorHeader,
        cancelButton
    };

    // Wire method to check if the current page is a community page
    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        // Check if currentPageReference exists
        if (currentPageReference) {
            // Check if the type of the current page is 'comm__namedPage'
            if (currentPageReference.type === 'comm__namedPage') {
                // Set the isCommunity property to true if the current page is a community page
                this.isCommunity = true;
            }
        }
    }

    // Lifecycle hook to execute when the component is inserted into the DOM
    connectedCallback() {
        try {
            // setting sorting order to ASC if default value is not provided
            this.sortingOrder = (this.sortingOrder !== 'ASC' && this.sortingOrder !== 'DESC') ? 'ASC' : this.sortingOrder;
            // Cofiguring Strip Color Of Timeline
            this.setStyle('--timeline-item-color', this.stripColor);
            // Cofiguring Icon Background Color
            this.iconBgColor = '--sds-c-icon-color-background:' + this.iconBackgroundColor + ';';
            // Cofiguring Icon Task Color
            this.iconStandardTaskColor = 'background-color:' + this.iconBackgroundColor + ';';
            // Cofiguring Icon Name
            this.iconVlaue = 'action:' + this.iconName;
            // Splitting the comma seperated array to an array.
            this.fieldsArray = this.fields.split(',');
            // Calling the apex class
            this.getData();
        } catch (error) {
            console.error(error);
        }

    }

    // Lifecycle hook to execute when the component is rendered
    renderedCallback() {
        try { // Getting the width of lwc component rendered.
            const element = this.template.querySelector('.checkWidth');
            this.componentWidth = element.getBoundingClientRect().width;
            // Setting the value of the large, small & medium screen
            if (this.componentWidth >= 950) {
                this.gridClass ='gridDisplay showFiveColoums';
            } else if (this.componentWidth < 950 && this.componentWidth >= 550) {
                this.gridClass = 'gridDisplay showThreeColoums';
            } else {
                this.gridClass = 'gridDisplay showTwoColoums';
            }

        } catch (error) {
            console.error(error);
        }
    }

    // Method to fetch data from the Apex controller
    getData() {
        try {
            getDetails({ parentObject: this.parentObject, childObject: this.childObject, fieldList: this.fieldsArray, recordId: this.recordId, sortingField: this.sortingField, sortingOrder: this.sortingOrder, header: this.header })
                .then(result => {
                    if (result.isError) {
                        this.isError = true;
                        this.isLoader = false;
                        this.errorMessage = result.errorMessage;
                    } else {
                        this.isHeaderExists = result.isHeaderExists;
                        this.isSortingFieldExists = result.isSortingFieldExists;
                        this.isIconNamePresent = result.isIconNamePresent;
                        this.fieldMap = result.fieldMap;
                        for (let [key, value] of Object.entries(this.fieldMap)) {
                            this.fieldMapDetail.push({
                                fieldapiName: key,
                                fieldLabel: value
                            })
                        }
                        this.childData = result.recordData;
                        if (this.childData.length == 0) {
                            this.isRecordsVisible = false;
                        } else {
                            this.isRecordsVisible = true;
                        }
                        this.childData.forEach(item => {
                            item.isTimelineVisible = true;
                            item.timeLineIcon = 'utility:chevrondown';
                            if (this.isHeaderExists == true) {
                                if (item[this.header] != undefined && item[this.header] != '' && item[this.header] != null) {
                                    item.headerName = item[this.header];
                                }
                                else {
                                    item.headerName = '';
                                }
                            } else {
                                item.headerName = item.Name;
                                let warningMessage = this.header + ', ' + this.label.headerWarningMessgae;
                                this.showToastDynamic(this.label.warningMessageHeader, warningMessage, 'warning');
                            }
                            if (!this.isSortingFieldExists && this.isSortingFieldExists != undefined) {
                                let warningMessage = this.sortingField + ', ' + this.label.sortingFieldWarningMessgae;
                                this.showToastDynamic(this.label.warningMessageHeader, warningMessage, 'warning');
                            }
                            if (item.Icon_Name__c == undefined || item.Icon_Name__c == '' || item.Icon_Name__c == null) {
                                item.iconVlaue = this.iconVlaue;
                                item.iconBgColor = this.iconBgColor;
                                item.iconStandardTaskColor = this.iconStandardTaskColor;
                            } else {
                                let iconNameParts = item.Icon_Name__c.split(',');
                                let iconName = this.iconVlaue;
                                let iconColor = this.iconBgColor;
                                if (iconNameParts[0] == undefined || iconNameParts[0] == '' || iconNameParts[0] == null) {
                                    iconName = this.iconVlaue;
                                } else {
                                    iconName = iconNameParts[0];
                                }
                                if (iconNameParts[1] == undefined || iconNameParts[1] == '' || iconNameParts[1] == null) {
                                    iconColor = this.iconBgColor;
                                } else {
                                    iconColor = iconNameParts[1];
                                }
                                item.iconVlaue = 'action:' + iconName;
                                item.iconBgColor = '--sds-c-icon-color-background:' + iconColor + ';';
                                item.iconStandardTaskColor = 'background-color:' + iconColor + ';';
                            }
                        });
                    }
                })
                .catch(error => {
                    this.isError = true;
                    this.isLoader = false;
                    this.errorMessage = error.body.message || error.body;
                    console.error(error);
                });
        } catch (error) {
            console.error(error);
            this.isLoader = false;
        }

    }
    loadRecordView(){
        try{
            this.isLoader = false;
        }catch(error){
            console.error(error);
        }
    }
    // Method to set CSS property and value
    setStyle(property, value) {
        try {
            this.template.host.style.setProperty(property, value);
        } catch (error) {
            console.error(error);
        }
    }

    // Method to navigate to a specific record
    navigateToRecord(event) {
        try {
            const recordId = event.currentTarget.dataset.id;
            const url = `/lightning/r/ObjectName/${recordId}/view`;
            window.open(url, '_blank');
        } catch (error) {
            console.error(error);
        }

    }

    // Method to toggle visibility of timeline items
    toggleTimeline(event) {
        try {
            const dataId = event.currentTarget.dataset.id;
            this.childData = this.childData.map(item => {
                if (item.Id === dataId) {
                    let iconName = item.isTimelineVisible ? 'utility:chevronright' : 'utility:chevrondown';
                    return { ...item, isTimelineVisible: !item.isTimelineVisible, timeLineIcon: iconName };
                }
                return item;
            });
        } catch (error) {
            console.error(error);
        }
    }

    // Method to handle the edit record action
    handleEditRecord(event) {
        try {
            this.childObjectRecordId = event.currentTarget.dataset.id;
            this.showEditModelBox = true;
            this.isLoadingModel = true;
        } catch (error) {
            console.error(error);
        }
    }

    // Method to hide the edit modal box
    hideEditModelBox() {
        try {
            this.childObjectRecordId = '';
            this.isLoadingModel = false;
            this.showEditModelBox = false;
        } catch (error) {
            console.error(error);
        }
    }
    handleModalLoad() {
        try {
            this.isLoadingModel = false;
        } catch (error) {
            console.error(error);
        }
    }
    // Method to handle save click in the edit modal box
    handleSaveClick() {
        try {
            this.isLoadingModel = true;
            this.template.querySelector('lightning-record-edit-form').submit();
        } catch (error) {
            console.error(error);
        }
    }

    // Method to handle successful save operation
    handleSuccess() {
        try {
            this.isLoadingModel = false;
            this.showToastDynamic(this.label.successHeader, this.label.successMessage, 'success');
            this.showEditModelBox = false;
        } catch (error) {
            console.error(error);
        }
    }

    // Method to handle error during save operation
    handleError(event) {
        try {
            this.isLoadingModel = false;
            event.preventDefault();
            event.stopImmediatePropagation();
            this.showToastDynamic(this.label.errorHeader, event.detail.detail, 'error');
        } catch (error) {
            console.error(error);
        }
    }

    // Method to show dynamic toast messages
    showToastDynamic(title, message, variant) {
        try {
            const evt = new ShowToastEvent({
                title: title,
                message: message,
                variant: variant,
                mode: 'dismissable'
            });
            this.dispatchEvent(evt);
        } catch (error) {
            console.error(error);
        }
    }
}